module.exports = {
        localServerDomain: '//192.168.1.13:8011', // 日志服务域pei
        localAssetsDomain: '//192.168.1.13:8010', // 可是化服务域名
        localServerPort: '8011',  // 日志服务端口号
        localAssetsPort: '8010',  // 可视化系统端口号

        messageQueue: false,  // 是否开启消息对列
        purchaseCode: 'OWOZ1WTZD2KBKRLKNPUZ', // 激活码
        email: 'm15225981276@163.com',  // 接收警报的邮箱
        emailPassword: '123456..' // 邮箱密码
}

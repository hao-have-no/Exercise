 ### 本系统来自于https://github.com/a597873885/webfunny_monitor,属于他人开发的开源产品,只不过针对自己的需求,做了一些特殊的更改
 
 ####插入探针,甚至用户id,和项目版本号,多项目监听
 window.webfunny && webfunny.wmInitUser("userId", "projectVersion")
 
 
 ### 前言
   怎样定位前端线上问题，一直以来，都是很头疼的问题，因为它发生于用户的一系列操作之后。错误的原因可能源于机型，网络环境，复杂的操作行为等等，在我们想要去解决的时候很难复现出来，自然也就无法解决。 当然，这些问题并非不能克服，让我们来一起看看如何去监控并定位线上的问题吧。
   

 ### 部署
 https://github.com/hao-have-no/webfunny_monitor/blob/master/Document_advanced.md
 
 important:在根目录下执行：chmod 755 restart.sh ，给 restart.sh 脚本文件执行权限 (linux、macOs环境下)
 
 ### 启动-本地
  1. npm run local_start 本地启动
  2. 根据启动信息,打开系统(eg:192.168.1.13:8010/webfunny/overview.html),注册成功后在系统页面插入探针
  3. 在浏览器控制台执行：webfunny.wm_check()，即可检查配置信息是否正确。
  4. 等待数据的路,一般来说,运行七天后所有的功能将可以使用
  
 ###  线上部署 
   1. 在根目录下执行：npm run prd ,即可启动生产环境服务  
   2. 常用命令如下：
   执行命令： pm2 log 可查看启动日志
   执行命令： pm2 list 可查已经启动的列表
   执行命令： pm2 stop webfunny 停止当前服务
   执行命令： pm2 delete webfunny 删除当前服务
   
---------------------------------------------------------

### 主体功能
1. 监控JS报错、http接口报错、静态资源加载报错等；记录页面访问、点击事件、接口请求等行为日志；

2. 统计PV/UV数据、用户7天留存数据、版本号/机型/地域分布数据

3. 提供报错具体查找和定位功能、用户详细行为追踪与分析功能、用户网络环境评估功能

4. 提供额外上报接口，上报自定义日志


### 目录结构
         ./A-monitor-code/webmonitor.js   探针代码
         ./schema  数据库建表结构
         ./views/ 前端展示代码
         ./config  数据库配置目录
         ./logs  运行报错日志目录
         ./config.js 接口配置文件



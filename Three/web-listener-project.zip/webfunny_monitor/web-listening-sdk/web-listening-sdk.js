!function (o) {
    var n = {};

    function r(e) {
        if (n[e]) return n[e].exports;
        var t = n[e] = {i: e, l: !1, exports: {}};
        return o[e].call(t.exports, t, t.exports, r), t.l = !0, t.exports
    }

    r.m = o, r.c = n, r.d = function (e, t, o) {
        r.o(e, t) || Object.defineProperty(e, t, {enumerable: !0, get: o})
    }, r.r = function (e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {value: "Module"}), Object.defineProperty(e, "__esModule", {value: !0})
    }, r.t = function (t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var o = Object.create(null);
        if (r.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: t
        }), 2 & e && "string" != typeof t) for (var n in t) r.d(o, n, function (e) {
            return t[e]
        }.bind(null, n));
        return o
    }, r.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return r.d(t, "a", t), t
    }, r.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, r.p = "", r(r.s = 0)
}([function (e, t, o) {
    o(1), e.exports = o(2)
}, function (e, t) {
    !function (u) {
        sessionStorage || (u.sessionStorage = new Object);
        var t = u.location.href.split("?")[0].replace("#", ""), s = null, a = performance && performance.timing,
            c = performance && "function" == typeof performance.getEntries ? performance.getEntries() : null,
            l = sessionStorage.CUSTOMER_WEB_MONITOR_ID || "webfunny_1583219255921",
            e = -1 === u.location.href.indexOf("https") ? "http://" : "https://", n = (u.location.href, ""),
            o = e + "192.168.1.13:8011", h = "/server/upLog", p = "/server/upDLog", d = o + h, f = o + p,
            g = o + "/server/pf", y = o, m = "CUSTOMER_PV", b = "LOAD_PAGE", v = "HTTP_LOG", w = "JS_ERROR",
            S = "SCREEN_SHOT", x = "ELE_BEHAVIOR", E = "RESOURCE_LOAD", O = "CUSTOMIZE_BEHAVIOR", r = "VIDEOS_EVENT",
            T = (u.navigator.userAgent, new function () {
                this.getUuid = function () {
                    var e = (new Date).getTime();
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (e) {
                        var t = 16 * Math.random() | 0;
                        return ("x" == e ? t : 3 & t | 8).toString(16)
                    }) + "-" + e
                }, this.getCustomerKey = function () {
                    var e = this.getUuid(), t = T.getCookie("monitorCustomerKey");
                    if (!t) {
                        var o = new Date;
                        o.setTime(o.getTime() + 15552e7), document.cookie = "monitorCustomerKey=" + e + ";Path=/;domain=" + n + ";expires=" + o.toGMTString(), t = e
                    }
                    return t
                }, this.getCookie = function (e) {
                    var t, o = new RegExp("(^| )" + e + "=([^;]*)(;|$)");
                    return document.cookie.match(o) ? (t = document.cookie.match(o), unescape(t[2])) : ""
                }, this.getPageKey = function () {
                    var e = this.getUuid();
                    return localStorage.monitorPageKey && /^[0-9a-z]{8}(-[0-9a-z]{4}){3}-[0-9a-z]{12}-\d{13}$/.test(localStorage.monitorPageKey) || (localStorage.monitorPageKey = e), localStorage.monitorPageKey
                }, this.setPageKey = function () {
                    localStorage.monitorPageKey = this.getUuid()
                }, this.addLoadEvent = function (e) {
                    var t = u.onload;
                    "function" != typeof u.onload ? u.onload = e : u.onload = function () {
                        t(), e()
                    }
                }, this.addOnclickForDocument = function (e) {
                    var t = document.onclick;
                    "function" != typeof document.onclick ? document.onclick = e : document.onclick = function () {
                        t(), e()
                    }
                }, this.ajax = function (e, t, o, n, r) {
                    try {
                        var i = u.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                        i.open(e, t, !0), i.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), i.onreadystatechange = function () {
                            if (4 == i.readyState) {
                                var t = {};
                                try {
                                    t = i.responseText ? JSON.parse(i.responseText) : {}
                                } catch (e) {
                                    console.error(i.responseText), t = {}
                                }
                                "function" == typeof n && n(t)
                            } else "function" == typeof r && r()
                        };
                        var a = JSON.stringify(o || {});
                        i.send("data=" + a)
                    } catch (e) {
                        console.warn(e)
                    }
                }, this.screenShot = function (e, r) {
                    var t = e, o = t.offsetWidth, n = t.offsetHeight, i = document.createElement("canvas");
                    i.style.display = "none", i.width = .3 * o, i.height = .3 * n, i.getContext("2d").scale(.3, .3);
                    var a = {scale: .3, canvas: i, logging: !1, width: o, height: n, useCORS: !0};
                    u.html2canvas && u.html2canvas(e, a).then(function (e) {
                        var t = e.toDataURL("image/webp").replace("data:image/webp;base64,", ""),
                            o = T.b64EncodeUnicode(t), n = new F(S, r, o);
                        n.handleLogInfo(S, n)
                    })
                }, this.initDebugTool = function () {
                    var i = localStorage.wmUserInfo ? JSON.parse(localStorage.wmUserInfo) : {}, t = {};
                    for (key in localStorage) "function" == typeof localStorage[key] || -1 != R.indexOf(key) || 1e3 < localStorage[key].length || (t[key] = localStorage[key]);
                    try {
                        t = T.b64EncodeUnicode(JSON.stringify(t))
                    } catch (e) {
                        t = ""
                    }
                    var o = {};
                    for (key in sessionStorage) "function" == typeof sessionStorage[key] || -1 != R.indexOf(key) || 1e3 < sessionStorage[key].length || (o[key] = sessionStorage[key]);
                    try {
                        o = T.b64EncodeUnicode(JSON.stringify(o))
                    } catch (e) {
                        o = ""
                    }
                    var e = T.b64EncodeUnicode(document.cookie);

                    function n(e) {
                        for (var t = [], o = e.length, n = 0; n < o; n++) t.push(e[n]);
                        var r = {};
                        return r.log = t, r.userId = i.userId, r.happenTime = (new Date).getTime(), T.b64EncodeUnicode(encodeURIComponent(JSON.stringify(r)))
                    }

                    T.ajax("POST", f, {localInfo: t, sessionInfo: o, cookieInfo: e}, function () {
                    });
                    var r = console.log, a = console.warn;
                    console.log = function () {
                        var e = n(arguments);
                        return T.ajax("POST", f, {consoleInfo: e}, function () {
                        }), r.apply(console, arguments)
                    }, console.warn = function () {
                        var e = n(arguments);
                        return T.ajax("POST", f, {warnInfo: e}, function () {
                        }), a.apply(console, arguments)
                    }, T.loadJs("//cdn.bootcss.com/lz-string/1.4.4/lz-string.js", function () {
                        T.loadJs("//cdn.jsdelivr.net/npm/rrweb@latest/dist/rrweb.min.js", function () {
                            s = rrweb.record({
                                emit: function (e) {
                                    var t = {event: e, userId: i.userId};
                                    t = JSON.stringify(t), T.ajax("POST", f, {videosInfo: t}, function () {
                                    })
                                }
                            })
                        })
                    })
                }, this.encryptObj = function (e) {
                    if (e instanceof Array) {
                        for (var t = [], o = 0; o < e.length; ++o) t[o] = this.encryptObj(e[o]);
                        return t
                    }
                    if (e instanceof Object) {
                        t = {};
                        for (var o in e) t[o] = this.encryptObj(e[o]);
                        return t
                    }
                    return 50 < (e += "").length && (e = e.substring(0, 10) + "****" + e.substring(e.length - 9, e.length)), e
                }, this.compressJson = function (e) {
                    if (e instanceof Array) {
                        for (var t = [], o = 0; o < e.length; ++o) t[o] = this.compressJson(e[o]);
                        return t
                    }
                    if (e instanceof Object) {
                        t = {};
                        for (var o in e) {
                            if ("_cssText" == o) for (var n in e[o] = e[o].replace(/ {/g, "{").replace(/; /g, ";").replace(/: /g, ":").replace(/, /g, ",").replace(/{ /g, "{"), N) {
                                var r = N[n], i = new RegExp(n, "g");
                                e[o] = e[o].replace(i, r)
                            }
                            L[o] ? (t[L[o]] = this.compressJson(e[o]), delete t[o]) : t[o] = this.compressJson(e[o])
                        }
                        return t
                    }
                    return e
                }, this.Compress = function (e) {
                    var t = "", o = new Array;
                    for (l = 0; l < 128; l++) o[l] = l;
                    for (var n = 128, r = 0, i = 0, a = 0, s = 0, c = 0, l = 0; l < e.length; l++) null != o[c = a << 8 | (s = e.charCodeAt(l))] ? a = o[c] : (i <<= 12, i |= a, a = s, 16 <= (r += 12) && (t += String.fromCharCode(i >> r - 16), i &= Math.pow(2, r - 16) - 1, r -= 16), n < 4096 && (n++, o[c] = n - 1));
                    return 0 != a && (r += 12, i <<= 12, i |= a), 16 <= r && (t += String.fromCharCode(i >> r - 16), i &= Math.pow(2, r - 16) - 1, r -= 16), 0 < r && (i <<= 16 - r, t += String.fromCharCode(i)), t
                }, this.Decompress = function (e) {
                    var t = "", o = new Array;
                    for (l = 0; l < 128; l++) o[l] = String.fromCharCode(l);
                    for (var n = 128, r = 0, i = 0, a = 0, s = 0, c = 0, l = 0; l < e.length; l++) for (r += 16, i <<= 16, i |= e.charCodeAt(l); 12 <= r;) s = void 0 !== (c = o[a = i >> r - 12]) ? (t += c, 128 < n && (o[o.length] = o[s] + c.substr(0, 1)), a) : (t += c = o[s] + o[s].substr(0, 1), o[o.length] = o[s] + c.substr(0, 1), o.length - 1), n++, r -= 12, i &= Math.pow(2, r) - 1;
                    return t
                }, this.getDevice = function () {
                    var e = {}, t = navigator.userAgent, o = t.match(/(Android);?[\s\/]+([\d.]+)?/),
                        n = t.match(/(iPad).*OS\s([\d_]+)/), r = t.match(/(iPod)(.*OS\s([\d_]+))?/),
                        i = !n && t.match(/(iPhone\sOS)\s([\d_]+)/), a = t.match(/Android\s[\S\s]+Build\//);
                    if (e.ios = e.android = e.iphone = e.ipad = e.androidChrome = !1, e.isWeixin = /MicroMessenger/i.test(t), e.os = "web", e.deviceName = "PC", o && (e.os = "android", e.osVersion = o[2], e.android = !0, e.androidChrome = 0 <= t.toLowerCase().indexOf("chrome")), (n || i || r) && (e.os = "ios", e.ios = !0), i && !r && (e.osVersion = i[2].replace(/_/g, "."), e.iphone = !0), n && (e.osVersion = n[2].replace(/_/g, "."), e.ipad = !0), r && (e.osVersion = r[3] ? r[3].replace(/_/g, ".") : null, e.iphone = !0), e.ios && e.osVersion && 0 <= t.indexOf("Version/") && "10" === e.osVersion.split(".")[0] && (e.osVersion = t.toLowerCase().split("version/")[1].split(" ")[0]), e.iphone) {
                        e.deviceName = "iphone";
                        var s = u.screen.width, c = u.screen.height;
                        320 === s && 480 === c ? e.deviceName = "iphone 4" : 320 === s && 568 === c ? e.deviceName = "iphone 5/SE" : 375 === s && 667 === c ? e.deviceName = "iphone 6/7/8" : 414 === s && 736 === c ? e.deviceName = "iphone 6/7/8 Plus" : 375 === s && 812 === c && (e.deviceName = "iphone X/S/Max")
                    } else if (e.ipad) e.deviceName = "ipad"; else if (a) {
                        var l = a[0].split(";")[1].replace(/Build\//g, "");
                        e.deviceName = l.replace(/(^\s*)|(\s*$)/g, "")
                    }
                    if (-1 == t.indexOf("Mobile")) {
                        var d = navigator.userAgent.toLowerCase();
                        if (e.browserName = "未知", 0 < d.indexOf("msie")) {
                            var f = d.match(/msie [\d.]+;/gi)[0];
                            e.browserName = f.split("/")[0], e.browserVersion = f.split("/")[1]
                        }
                        if (0 < d.indexOf("firefox")) {
                            f = d.match(/firefox\/[\d.]+/gi)[0];
                            e.browserName = f.split("/")[0], e.browserVersion = f.split("/")[1]
                        }
                        if (0 < d.indexOf("safari") && d.indexOf("chrome") < 0) {
                            f = d.match(/safari\/[\d.]+/gi)[0];
                            e.browserName = f.split("/")[0], e.browserVersion = f.split("/")[1]
                        }
                        if (0 < d.indexOf("chrome")) {
                            f = d.match(/chrome\/[\d.]+/gi)[0];
                            e.browserName = f.split("/")[0], e.browserVersion = f.split("/")[1]
                        }
                    }
                    return e.webView = (i || n || r) && t.match(/.*AppleWebKit(?!.*Safari)/i), e
                }, this.loadJs = function (e, t) {
                    var o = document.createElement("script");
                    o.async = 1, o.src = e, o.onload = t;
                    var n = document.getElementsByTagName("script")[0];
                    return n.parentNode.insertBefore(o, n), n
                }, this.b64EncodeUnicode = function (t) {
                    try {
                        return btoa(encodeURIComponent(t).replace(/%([0-9A-F]{2})/g, function (e, t) {
                            return String.fromCharCode("0x" + t)
                        }))
                    } catch (e) {
                        return t
                    }
                }, this.char2buf = function (e) {
                    for (var t = new ArrayBuffer(2 * e.length), o = new Uint16Array(t), n = e.split(""), r = 0; r < n.length; r++) o[r] = n[r].charCodeAt();
                    return t
                }
            }), i = T.getDevice(), U = "", I = "", _ = "", k = "", j = "", P = "", C = "",
            A = localStorage.wmUserInfo ? JSON.parse(localStorage.wmUserInfo) : {}, L = {
                type: "≠",
                childNodes: "ā",
                name: "á",
                id: "ǎ",
                tagName: "à",
                attributes: "ē",
                style: "é",
                textContent: "ě",
                isStyle: "è",
                isSVG: "ī",
                content: "í",
                href: "ǐ",
                src: "ì",
                class: "ō",
                tabindex: "ó",
                "aria-label": "ǒ",
                viewBox: "ò",
                focusable: "ū",
                "data-icon": "ú",
                width: "ǔ",
                height: "ù",
                fill: "ǖ",
                "aria-hidden": "ǘ",
                stroke: "ǚ",
                "stroke-width": "ǜ",
                "paint-order": "ü",
                "stroke-opacity": "ê",
                "stroke-dasharray": "ɑ",
                "stroke-linecap": "?",
                "stroke-linejoin": "ń",
                "stroke-miterlimit": "ň",
                "clip-path": "Γ",
                "alignment-baseline": "Δ",
                "fill-opacity": "Θ",
                transform: "Ξ",
                "text-anchor": "Π",
                offset: "Σ",
                "stop-color": "Υ",
                "stop-opacity": "Φ"
            }, N = {
                background: "≠",
                "background-attachment": "ā",
                "background-color": "á",
                "background-image": "ǎ",
                "background-position": "à",
                "background-repeat": "ē",
                "background-clip": "é",
                "background-origin": "ě",
                "background-size": "è",
                border: "Г",
                "border-bottom": "η",
                color: "┯",
                style: "Υ",
                width: "б",
                "border-color": "ū",
                "border-left": "ǚ",
                "border-right": "ň",
                "border-style": "Δ",
                "border-top": "З",
                "border-width": "Ω",
                outline: "α",
                "outline-color": "β",
                "outline-style": "γ",
                "outline-width": "δ",
                "left-radius": "Ж",
                "right-radius": "И",
                "border-image": "ω",
                outset: "μ",
                repeat: "ξ",
                repeated: "π",
                rounded: "ρ",
                stretched: "σ",
                slice: "υ",
                source: "ψ",
                "border-radius": "Б",
                radius: "Д",
                "box-decoration": "Й",
                break: "К",
                "box-shadow": "Л",
                "overflow-x": "Ф",
                "overflow-y": "У",
                "overflow-style": "Ц",
                rotation: "Ч",
                "rotation-point": "Щ",
                opacity: "Ъ",
                height: "Ы",
                "max-height": "Э",
                "max-width": "Ю",
                "min-height": "Я",
                "min-width": "а",
                font: "в",
                "font-family": "г",
                "font-size": "ж",
                adjust: "з",
                aspect: "и",
                "font-stretch": "й",
                "font-style": "к",
                "font-variant": "л",
                "font-weight": "ф",
                content: "ц",
                before: "ч",
                after: "ш",
                "counter-increment": "щ",
                "counter-reset": "ъ",
                quotes: "ы",
                "list-style": "+",
                image: "－",
                position: "|",
                type: "┌",
                margin: "┍",
                "margin-bottom": "┎",
                "margin-left": "┏",
                "margin-right": "┐",
                "margin-top": "┑",
                padding: "┒",
                "padding-bottom": "┓",
                "padding-left": "—",
                "padding-right": "┄",
                "padding-top": "┈",
                bottom: "├",
                clear: "┝",
                clip: "┞",
                cursor: "┟",
                display: "┠",
                float: "┡",
                left: "┢",
                overflow: "┣",
                right: "┆",
                top: "┊",
                "vertical-align": "┬",
                visibility: "┭",
                "z-index": "┮",
                direction: "┰",
                "letter-spacing": "┱",
                "line-height": "┲",
                "text-align": "6",
                "text-decoration": "┼",
                "text-indent": "┽",
                "text-shadow": "10",
                "text-transform": "┿",
                "unicode-bidi": "╀",
                "white-space": "╂",
                "word-spacing": "╁",
                "hanging-punctuation": "╃",
                "punctuation-trim": "1",
                last: "3",
                "text-emphasis": "4",
                "text-justify": "5",
                justify: "7",
                "text-outline": "8",
                "text-overflow": "9",
                "text-wrap": "11",
                "word-break": "12",
                "word-wrap": "13"
            }, R = [x, w, v, S, m, b, E, O, r];

        function B() {
            this.handleLogInfo = function (e, t) {
                var o = localStorage[e] ? localStorage[e] : "";
                switch (e) {
                    case x:
                        localStorage[x] = o + JSON.stringify(t) + "$$$";
                        break;
                    case w:
                        localStorage[w] = o + JSON.stringify(t) + "$$$";
                        break;
                    case v:
                        localStorage[v] = o + JSON.stringify(t) + "$$$";
                        break;
                    case S:
                        localStorage[S] = o + JSON.stringify(t) + "$$$";
                        break;
                    case m:
                        localStorage[m] = o + JSON.stringify(t) + "$$$";
                        break;
                    case b:
                        localStorage[b] = o + JSON.stringify(t) + "$$$";
                        break;
                    case E:
                        localStorage[E] = o + JSON.stringify(t) + "$$$";
                        break;
                    case O:
                        localStorage[O] = o + JSON.stringify(t) + "$$$";
                        break;
                    case r:
                        localStorage[r] = o + JSON.stringify(t) + "$$$"
                }
            }
        }

        function D() {
            this.h = (new Date).getTime(), this.a = l, this.g = u.location.href.split("?")[0].replace("#", ""), this.f = T.b64EncodeUnicode(encodeURIComponent(u.location.href)), this.b = T.getCustomerKey();
            var e = localStorage.wmUserInfo ? JSON.parse(localStorage.wmUserInfo) : {};
            this.c = e.userId, this.d = T.b64EncodeUnicode(e.firstUserParam || ""), this.e = T.b64EncodeUnicode(e.secondUserParam || "")
        }

        function J(e, t, o, n) {
            D.apply(this), this.i = e, this.j = T.b64EncodeUnicode(A.projectVersion || ""), this.k = T.getPageKey(), this.l = i.deviceName, this.m = i.os + (i.osVersion ? " " + i.osVersion : ""), this.n = i.browserName, this.o = i.browserVersion, this.p = "", this.q = "china", this.r = "", this.s = "", this.t = t, this.u = o, this.newStatus = n
        }

        function $(e, t, o, n, r, i, a, s, c, l, d, f) {
            D.apply(this), this.i = e, this.t = t, this.v = o, this.w = n, this.x = r, this.y = i, this.z = a, this.A = s, this.B = c, this.C = l, this.D = d, this.E = f
        }

        function V(e, t, o, n, r, i, a) {
            D.apply(this), this.i = e, this.da = t, this.G = T.b64EncodeUnicode(o), this.H = T.b64EncodeUnicode(n), this.I = T.b64EncodeUnicode(r), this.L = i, this.M = T.b64EncodeUnicode(encodeURIComponent(a))
        }

        function M(e, t, o, n) {
            D.apply(this), this.i = e, this.O = t, this.k = T.getPageKey(), this.l = i.deviceName, this.m = i.os + (i.osVersion ? " " + i.osVersion : ""), this.n = i.browserName, this.o = i.browserVersion, this.p = "", this.q = "china", this.r = "", this.s = "", this.P = T.b64EncodeUnicode(o), this.Q = T.b64EncodeUnicode(n), this.R = ""
        }

        function H(e, t, o, n, r, i, a, s, c) {
            D.apply(this), this.i = e, this.g = t, this.S = T.b64EncodeUnicode(encodeURIComponent(o)), this.T = n, this.U = r, this.V = i, this.W = "", this.X = T.b64EncodeUnicode(a), this.h = s, this.u = c
        }

        function F(e, t, o, n) {
            D.apply(this), this.i = e, this.Y = T.b64EncodeUnicode(t), this.Z = o, this.aa = n || "jpeg"
        }

        function q(e, t, o, n) {
            D.apply(this), this.i = e, this.ba = o, this.ca = T.b64EncodeUnicode(encodeURIComponent(t)), this.T = n
        }

        function K(e, t, o, n, r) {
            this.c = e, this.da = t, this.ea = o, this.i = n, this.Y = r, this.h = (new Date).getTime()
        }

        function X() {
            var e = u.location.href.split("?")[0].replace("#", "");
            t != e && (z(), t = e)
        }

        function z() {
            T.setPageKey();
            var e = "load";
            c && (e = c[0] && "navigate" === c[0].type ? "load" : "reload");
            var t = T.getCookie("monitorCustomerKey");
            if (t) {
                var o = "", n = t ? t.match(/\d{13}/g) : [];
                if (n && 0 < n.length) {
                    var r = parseInt(n[0], 10);
                    o = 1e3 < (new Date).getTime() - r ? "old" : "new"
                }
            }
            var i = new J(m, e, 0, o);
            i.handleLogInfo(m, i)
        }

        function G(e, t, o, n, r, i) {
            X();
            var a = t || "", s = i || "", c = "";
            a && (c = "string" == typeof s ? s.split(": ")[0].replace('"', "") : JSON.stringify(s).split(": ")[0].replace('"', ""));
            var l = new M(w, e, c + ": " + a, s);
            l.handleLogInfo(w, l)
        }

        function W() {
            var n = console.error;
            console.error = function (e) {
                var t = e && e.message || e, o = e && e.stack;
                if (o) G("on_error", t, 0, 0, 0, o); else {
                    if ("object" == typeof t) try {
                        t = JSON.stringify(t)
                    } catch (e) {
                        t = "错误无法解析"
                    }
                    G("console_error", t, 0, 0, 0, "CustomizeError: " + t)
                }
                return n.apply(console, arguments)
            }, u.onerror = function (e, t, o, n, r) {
                !0, G("on_error", e, 0, 0, 0, r ? r.stack : null)
            }, u.onunhandledrejection = function (e) {
                var t = "", o = "";
                o = "object" == typeof e.reason ? (t = e.reason.message, e.reason.stack) : (t = e.reason, ""), G("on_error", t, 0, 0, 0, "UncaughtInPromiseError: " + o)
            }
        }

        function Y() {
            function t(e) {
                var t = new CustomEvent(e, {detail: this});
                u.dispatchEvent(t)
            }

            var o = u.XMLHttpRequest;

            function r(e, t) {
                if (f[e] && !0 !== f[e].uploadFlag) {
                    var o = "";
                    if (t && o.length < 500) try {
                        o = t ? JSON.stringify(T.encryptObj(JSON.parse(t))) : ""
                    } catch (e) {
                        o = ""
                    } else o = "data is too long";
                    var n = f[e].simpleUrl, r = (new Date).getTime(), i = f[e].event.detail.responseURL,
                        a = f[e].event.detail.status, s = f[e].event.detail.statusText, c = r - f[e].timeStamp;
                    if (i && -1 == i.indexOf(h) && -1 == i.indexOf(p)) {
                        var l = new H(v, n, i, a, s, "发起请求", "", f[e].timeStamp, 0);
                        l.handleLogInfo(v, l);
                        var d = new H(v, n, i, a, s, "请求返回", o, r, c);
                        d.handleLogInfo(v, d), f[e].uploadFlag = !0
                    }
                }
            }

            var f = [];
            u.XMLHttpRequest = function () {
                var e = new o;
                return e.addEventListener("abort", function () {
                    t.call(this, "ajaxAbort")
                }, !1), e.addEventListener("error", function () {
                    t.call(this, "ajaxError")
                }, !1), e.addEventListener("load", function () {
                    t.call(this, "ajaxLoad")
                }, !1), e.addEventListener("loadstart", function () {
                    t.call(this, "ajaxLoadStart")
                }, !1), e.addEventListener("progress", function () {
                    t.call(this, "ajaxProgress")
                }, !1), e.addEventListener("timeout", function () {
                    t.call(this, "ajaxTimeout")
                }, !1), e.addEventListener("loadend", function () {
                    t.call(this, "ajaxLoadEnd")
                }, !1), e.addEventListener("readystatechange", function () {
                    t.call(this, "ajaxReadyStateChange")
                }, !1), e
            }, u.addEventListener("ajaxLoadStart", function (e) {
                var t = {
                    timeStamp: (new Date).getTime(),
                    event: e,
                    simpleUrl: u.location.href.split("?")[0].replace("#", ""),
                    uploadFlag: !1
                };
                f.push(t)
            }), u.addEventListener("ajaxLoadEnd", function () {
                for (var n = 0; n < f.length; n++) {
                    if (!0 !== f[n].uploadFlag) if (0 < f[n].event.detail.status) if ("blob" === (f[n].event.detail.responseType + "").toLowerCase()) !function (t) {
                        var o = new FileReader;
                        o.onload = function () {
                            var e = o.result;
                            r(t, e)
                        };
                        try {
                            o.readAsText(f[n].event.detail.response, "utf-8")
                        } catch (e) {
                            r(t, f[n].event.detail.response + "")
                        }
                    }(n); else try {
                        var e = f[n] && f[n].event && f[n].event.detail;
                        if (!e) return;
                        var t = e.responseType, o = "";
                        "" !== t && "text" !== t || (o = e.responseText), "json" === t && (o = JSON.stringify(e.response)), r(n, o)
                    } catch (e) {
                    }
                }
            })
        }

        function Z(e) {
            e && e.record && 1 == e.record && (X(), T.addOnclickForDocument(function (e) {
                var t = "", o = "", n = "", r = e.target.tagName, i = "";
                "svg" != e.target.tagName && "use" != e.target.tagName && (t = e.target.className, o = e.target.placeholder || "", n = e.target.value || "", 200 < (i = e.target.innerText ? e.target.innerText.replace(/\s*/g, "") : "").length && (i = i.substring(0, 100) + "... ..." + i.substring(i.length - 99, i.length - 1)), i = i.replace(/\s/g, ""));
                var a = new V(x, "click", t, o, n, r, i);
                a.handleLogInfo(x, a)
            }))
        }

        J.prototype = new B, $.prototype = new B, V.prototype = new B, M.prototype = new B, H.prototype = new B, F.prototype = new B, q.prototype = new B, K.prototype = new B, new B, function () {
            var e = localStorage.sl, t = ["0", "1", "2", "3", "4", "5"];
            e && (t = e.split(""));
            try {
                for (var o = 0; o < t.length; o++) switch (t[o]) {
                    case"0":
                        z(), U = "启动...";
                        break;
                    case"1":
                        u.addEventListener("error", function (e) {
                            var t = e.target.localName, o = "";
                            "link" === t ? o = e.target.href : "script" === t && (o = e.target.src);
                            var n = new q(E, o, t, "0");
                            n.handleLogInfo(E, n)
                        }, !0), k = "启动...";
                        break;
                    case"2":
                        W(), I = "启动...";
                        break;
                    case"3":
                        Y(), _ = "启动...";
                        break;
                    case"4":
                        T.addLoadEvent(function () {
                            setTimeout(function () {
                                if (c) {
                                    var e = "load";
                                    e = c[0] && "navigate" === c[0].type ? "load" : "reload";
                                    var t = a, o = new $(b);
                                    o.loadType = e, o.loadPage = t.loadEventEnd - t.navigationStart, o.domReady = t.domComplete - t.responseEnd, o.redirect = t.redirectEnd - t.redirectStart, o.lookupDomain = t.domainLookupEnd - t.domainLookupStart, o.ttfb = t.responseStart - t.navigationStart, o.request = t.responseEnd - t.requestStart, o.loadEvent = t.loadEventEnd - t.loadEventStart, o.appcache = t.domainLookupStart - t.fetchStart, o.unloadEvent = t.unloadEventEnd - t.unloadEventStart, o.connect = t.connectEnd - t.connectStart, o.handleLogInfo(b, o)
                                }
                                !function () {
                                    var e = localStorage.ds;
                                    if (e) if ("connected" === e) {
                                        if (s) return;
                                        T.initDebugTool()
                                    } else "disconnect" === e && s && (s(), s = null); else {
                                        var t = localStorage.wmUserInfo ? JSON.parse(localStorage.wmUserInfo) : {};
                                        if (!t.userId) return;
                                        T.ajax("GET", g + "?webMonitorId=" + l + "&userId=" + t.userId, {}, function (e) {
                                            if (localStorage.ds = e && e.data && e.data.d || "disconnect", localStorage.sl = e && e.data && e.data.s || "012345", "connected" == localStorage.ds) {
                                                if (s) return;
                                                T.initDebugTool()
                                            }
                                        })
                                    }
                                }()
                            }, 1e3)
                        }), P = "启动...";
                        break;
                    case"5":
                        Z({record: 1}), j = "启动..."
                }
                var n = 0, r = 0, i = R;
                setInterval(function () {
                    if (X(), 40 <= n) {
                        for (var e = "", t = 0; t < i.length; t++) e += localStorage[i[t]] || "";
                        if (e.split("$$$").length < 10 && r < 1) return r++, void (n = 0);
                        (r = 0) < e.length && T.ajax("POST", d, {logInfo: e}, function (e) {
                            for (var t = 0; t < i.length; t++) localStorage[i[t]] = "";
                            e && e.data && e.data.d && (localStorage.ds = "c" == e.data.d ? "connected" : "disconnect", localStorage.sl = e.data.s || "012345")
                        }, function () {
                            for (var e = 0; e < i.length; e++) localStorage[i[e]] = ""
                        }), n = 0
                    }
                    n++
                }, 200)
            } catch (e) {
                console.error("监控代码异常，捕获", e)
            }
        }(), u.webfunny = {
            wm_check: function () {
                var e = "未启动！";
                return console.log("================================配置检查==============================="), console.log("=【身份标识】：" + localStorage.wmUserInfo), console.log("=【探针标识】：" + l), console.log("=【上报接口】：" + d), console.log("=【启动列表】：" + localStorage.sl), console.log("......................................................................"), console.log("= PVUV监控状态：" + (U || e)), console.log("= 静态资源监控状态：" + (k || e)), console.log("= JS错误监控状态：" + (I || e)), console.log("= 接口请求监控状态：" + (_ || e)), console.log("= 页面加载监控状态：" + (P || e)), console.log("= 用户行为监控状态：" + (j || e)), console.log("= 用户信息初始化状态：" + (C || "未初始化！部分功能将无法使用，请查看文档(API方法调用)，执行webfunny.wmInitUser方法进行初始化！")), console.log("======================================================================"), "结束"
            }, wm_upload: function (e, t, o, n) {
                var r = (new Date).toString(), i = {
                    createTime: encodeURIComponent(r),
                    happenTime: (new Date).getTime(),
                    uploadType: "WM_UPLOAD",
                    simpleUrl: encodeURIComponent(encodeURIComponent(e)),
                    webMonitorId: l,
                    recordType: t,
                    recordIndex: o,
                    description: n
                }, a = y, s = u.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                s.open("POST", a, !0), s.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), s.send("data=" + JSON.stringify([i]))
            }, wm_init_user: function (e, t, o) {
                return e || console.warn("userId 初始化值为0(不推荐) 或者 未初始化"), o || console.warn("secondParam 初始化值为0(不推荐) 或者 未初始化"), t && (l = t + "_webmonitor"), localStorage.wmUserInfo = JSON.stringify({
                    userId: e,
                    userTag: t,
                    secondUserParam: o
                }), 1
            }, wmInitUser: function (e, t) {
                return e || console.warn("userId(用户唯一标识) 初始化值为0(不推荐) 或者 未传值, 探针可能无法生效"), t || console.warn("projectVersion(应用版本号) 初始化值为0(不推荐) 或者 未传值, 探针可能无法生效"), localStorage.wmUserInfo = JSON.stringify({
                    userId: e,
                    projectVersion: t
                }), C = "用户信息初始化：userId=" + e + "，版本号：" + t, 1
            }, wm_screen_shot: function (e) {
                T.screenShot(document.body, e)
            }, wm_upload_picture: function (e, t, o) {
                var n = new F(S, t, e, o || "jpeg");
                n.handleLogInfo(S, n)
            }, wm_upload_extend_log: function (e, t, o, n, r) {
                var i = new K(e, t, o, n, r);
                i.handleLogInfo(O, i)
            }
        }, function () {
            if ("function" == typeof u.CustomEvent) return;

            function e(e, t) {
                t = t || {bubbles: !1, cancelable: !1, detail: void 0};
                var o = document.createEvent("CustomEvent");
                return o.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), o
            }

            e.prototype = u.Event.prototype, u.CustomEvent = e
        }()
    }(window)
}, function (e, t) {
    !function (e) {
        var t = "URLSearchParams" in e, o = "Symbol" in e && "iterator" in Symbol,
            a = "FileReader" in e && "Blob" in e && function () {
                try {
                    return new Blob, !0
                } catch (e) {
                    return !1
                }
            }(), n = "FormData" in e, r = "ArrayBuffer" in e;
        if (r) var i = ["[object Int8Array]", "[object Uint8Array]", "[object Uint8ClampedArray]", "[object Int16Array]", "[object Uint16Array]", "[object Int32Array]", "[object Uint32Array]", "[object Float32Array]", "[object Float64Array]"],
            s = function (e) {
                return e && DataView.prototype.isPrototypeOf(e)
            }, c = ArrayBuffer.isView || function (e) {
                return e && -1 < i.indexOf(Object.prototype.toString.call(e))
            };

        function l(e) {
            if ("string" != typeof e && (e = String(e)), /[^a-z0-9\-#$%&'*+.\^_`|~]/i.test(e)) throw new TypeError("Invalid character in header field name");
            return e.toLowerCase()
        }

        function d(e) {
            return "string" != typeof e && (e = String(e)), e
        }

        function f(t) {
            var e = {
                next: function () {
                    var e = t.shift();
                    return {done: void 0 === e, value: e}
                }
            };
            return o && (e[Symbol.iterator] = function () {
                return e
            }), e
        }

        function u(t) {
            this.map = {}, t instanceof u ? t.forEach(function (e, t) {
                this.append(t, e)
            }, this) : Array.isArray(t) ? t.forEach(function (e) {
                this.append(e[0], e[1])
            }, this) : t && Object.getOwnPropertyNames(t).forEach(function (e) {
                this.append(e, t[e])
            }, this)
        }

        function h(e) {
            if (e.bodyUsed) return Promise.reject(new TypeError("Already read"));
            e.bodyUsed = !0
        }

        function p(o) {
            return new Promise(function (e, t) {
                o.onload = function () {
                    e(o.result)
                }, o.onerror = function () {
                    t(o.error)
                }
            })
        }

        function g(e) {
            var t = new FileReader, o = p(t);
            return t.readAsArrayBuffer(e), o
        }

        function y(e) {
            if (e.slice) return e.slice(0);
            var t = new Uint8Array(e.byteLength);
            return t.set(new Uint8Array(e)), t.buffer
        }

        function m() {
            return this.bodyUsed = !1, this._initBody = function (e) {
                if (this._bodyInit = e) if ("string" == typeof e) this._bodyText = e; else if (a && Blob.prototype.isPrototypeOf(e)) this._bodyBlob = e; else if (n && FormData.prototype.isPrototypeOf(e)) this._bodyFormData = e; else if (t && URLSearchParams.prototype.isPrototypeOf(e)) this._bodyText = e.toString(); else if (r && a && s(e)) this._bodyArrayBuffer = y(e.buffer), this._bodyInit = new Blob([this._bodyArrayBuffer]); else {
                    if (!r || !ArrayBuffer.prototype.isPrototypeOf(e) && !c(e)) throw new Error("unsupported BodyInit type");
                    this._bodyArrayBuffer = y(e)
                } else this._bodyText = "";
                this.headers.get("content-type") || ("string" == typeof e ? this.headers.set("content-type", "text/plain;charset=UTF-8") : this._bodyBlob && this._bodyBlob.type ? this.headers.set("content-type", this._bodyBlob.type) : t && URLSearchParams.prototype.isPrototypeOf(e) && this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"))
            }, a && (this.blob = function () {
                var e = h(this);
                if (e) return e;
                if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
                if (this._bodyArrayBuffer) return Promise.resolve(new Blob([this._bodyArrayBuffer]));
                if (this._bodyFormData) throw new Error("could not read FormData body as blob");
                return Promise.resolve(new Blob([this._bodyText]))
            }, this.arrayBuffer = function () {
                return this._bodyArrayBuffer ? h(this) || Promise.resolve(this._bodyArrayBuffer) : this.blob().then(g)
            }), this.text = function () {
                var e = h(this);
                if (e) return e;
                if (this._bodyBlob) return function (e) {
                    var t = new FileReader, o = p(t);
                    return t.readAsText(e), o
                }(this._bodyBlob);
                if (this._bodyArrayBuffer) return Promise.resolve(function (e) {
                    for (var t = new Uint8Array(e), o = new Array(t.length), n = 0; n < t.length; n++) o[n] = String.fromCharCode(t[n]);
                    return o.join("")
                }(this._bodyArrayBuffer));
                if (this._bodyFormData) throw new Error("could not read FormData body as text");
                return Promise.resolve(this._bodyText)
            }, n && (this.formData = function () {
                return this.text().then(w)
            }), this.json = function () {
                return this.text().then(JSON.parse)
            }, this
        }

        u.prototype.append = function (e, t) {
            e = l(e), t = d(t);
            var o = this.map[e];
            this.map[e] = o ? o + "," + t : t
        }, u.prototype.delete = function (e) {
            delete this.map[l(e)]
        }, u.prototype.get = function (e) {
            return e = l(e), this.has(e) ? this.map[e] : null
        }, u.prototype.has = function (e) {
            return this.map.hasOwnProperty(l(e))
        }, u.prototype.set = function (e, t) {
            this.map[l(e)] = d(t)
        }, u.prototype.forEach = function (e, t) {
            for (var o in this.map) this.map.hasOwnProperty(o) && e.call(t, this.map[o], o, this)
        }, u.prototype.keys = function () {
            var o = [];
            return this.forEach(function (e, t) {
                o.push(t)
            }), f(o)
        }, u.prototype.values = function () {
            var t = [];
            return this.forEach(function (e) {
                t.push(e)
            }), f(t)
        }, u.prototype.entries = function () {
            var o = [];
            return this.forEach(function (e, t) {
                o.push([t, e])
            }), f(o)
        }, o && (u.prototype[Symbol.iterator] = u.prototype.entries);
        var b = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];

        function v(e, t) {
            var o = (t = t || {}).body;
            if (e instanceof v) {
                if (e.bodyUsed) throw new TypeError("Already read");
                this.url = e.url, this.credentials = e.credentials, t.headers || (this.headers = new u(e.headers)), this.method = e.method, this.mode = e.mode, o || null == e._bodyInit || (o = e._bodyInit, e.bodyUsed = !0)
            } else this.url = String(e);
            if (this.credentials = t.credentials || this.credentials || "omit", !t.headers && this.headers || (this.headers = new u(t.headers)), this.method = function (e) {
                var t = e.toUpperCase();
                return -1 < b.indexOf(t) ? t : e
            }(t.method || this.method || "GET"), this.mode = t.mode || this.mode || null, this.referrer = null, ("GET" === this.method || "HEAD" === this.method) && o) throw new TypeError("Body not allowed for GET or HEAD requests");
            this._initBody(o)
        }

        function w(e) {
            var r = new FormData;
            return e.trim().split("&").forEach(function (e) {
                if (e) {
                    var t = e.split("="), o = t.shift().replace(/\+/g, " "), n = t.join("=").replace(/\+/g, " ");
                    r.append(decodeURIComponent(o), decodeURIComponent(n))
                }
            }), r
        }

        function S(e, t) {
            t = t || {}, this.type = "default", this.status = "status" in t ? t.status : 200, this.ok = 200 <= this.status && this.status < 300, this.statusText = "statusText" in t ? t.statusText : "OK", this.headers = new u(t.headers), this.url = t.url || "", this._initBody(e)
        }

        v.prototype.clone = function () {
            return new v(this, {body: this._bodyInit})
        }, m.call(v.prototype), m.call(S.prototype), S.prototype.clone = function () {
            return new S(this._bodyInit, {
                status: this.status,
                statusText: this.statusText,
                headers: new u(this.headers),
                url: this.url
            })
        }, S.error = function () {
            var e = new S(null, {status: 0, statusText: ""});
            return e.type = "error", e
        };
        var x = [301, 302, 303, 307, 308];
        S.redirect = function (e, t) {
            if (-1 === x.indexOf(t)) throw new RangeError("Invalid status code");
            return new S(null, {status: t, headers: {location: e}})
        }, e.Headers = u, e.Request = v, e.Response = S, e.fetch = function (o, n) {
            return fetchHttpUrl = o, new Promise(function (r, e) {
                var t = new v(o, n), i = new XMLHttpRequest;
                i.onload = function () {
                    var e = i.responseType, t = "", o = {
                        status: i.status, statusText: i.statusText, headers: function (e) {
                            var r = new u;
                            return e.split(/\r?\n/).forEach(function (e) {
                                var t = e.split(":"), o = t.shift().trim();
                                if (o) {
                                    var n = t.join(":").trim();
                                    r.append(o, n)
                                }
                            }), r
                        }(i.getAllResponseHeaders() || "")
                    };
                    o.url = "responseURL" in i ? i.responseURL : o.headers.get("X-Request-URL"), "" !== e && "text" !== e || (t = i.responseText), "json" === e && (t = i.response);
                    var n = "response" in i ? i.response : t;
                    r(new S(n, o))
                }, i.onerror = function () {
                    console.error("Network request failed"), e(new TypeError("Network request failed"))
                }, i.ontimeout = function () {
                    e(new TypeError("Network request failed"))
                }, i.open(t.method, t.url, !0), "include" === t.credentials && (i.withCredentials = !0), "responseType" in i && a && (i.responseType = "blob"), t.headers.forEach(function (e, t) {
                    i.setRequestHeader(t, e)
                }), i.send(void 0 === t._bodyInit ? null : t._bodyInit)
            })
        }, e.fetch.polyfill = !0
    }("undefined" != typeof self ? self : window)
}]);

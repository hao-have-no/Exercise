 #!/bin/bash
echo "开始执行创建命令"
npm run prd_restart
echo "数据库表创建完成"